$(function() {
  $('#texteJQ').html('Hello world. Ce texte est affiché par jQuery.');
});
